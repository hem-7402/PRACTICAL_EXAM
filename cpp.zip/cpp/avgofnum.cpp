#include<iostream>
using namespace std;
int main(){
    int a,b;
    cout << "enter first value : ";
    cin >> a;
    cout << "enter second value : ";
    cin >> b;
    int avg = (a + b) / 2;
    cout << "avg : " << avg;
    return 0;
}