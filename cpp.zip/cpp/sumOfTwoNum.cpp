#include<iostream>
using namespace std;
int main(){
    int a = 4, b = 24;
    int sum = a + b;
    cout << "sum of a + b : " << sum;     
    return 0;
}