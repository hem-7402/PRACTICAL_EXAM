#include<iostream>
using namespace std;
int main(){
    int l;
    cout << "enter area : ";
    cin >> l;
    int area = l * l;
    cout << "area of sum : " << area;
    return 0;
}