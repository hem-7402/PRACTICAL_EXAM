#include<iostream>
using namespace std;
int main(){
    int a = 10,b = 23,c = 43,d = 65;
    int sum = a + b + c + d;
    cout << "average of four given number : " << (sum / 4);
    return 0;
}