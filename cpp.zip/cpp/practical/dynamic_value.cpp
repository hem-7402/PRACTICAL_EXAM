#include<iostream>
using namespace std;
int main(){
    int a,b;
    cout << "enter value a : ";
    cin >> a;
    cout << "enter value b : ";
    cin >> b;

    cout << "value of a : " << a << endl;
    cout << "value of b : " << b << endl;
    return 0;
}

