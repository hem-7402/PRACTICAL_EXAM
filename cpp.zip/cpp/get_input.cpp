#include<iostream>
using namespace std;
int main(){
    int n;
    cout << "enter value : ";
    cin >> n;
    cout << n;
    return 0;
}